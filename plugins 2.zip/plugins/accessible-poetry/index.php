<?php
/**
 * AccessibleWP
 * 
 * @author      Amitmoreno, Codenroll
 * @author_url  https://amitmoreno.com/, https://www.codenroll.co.il/
 */
defined( 'ABSPATH' ) or die( 'No script kiddies please!' );